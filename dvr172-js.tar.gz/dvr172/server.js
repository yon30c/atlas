NetPort=6036
NetAddr=""
ServerType=9
bUseNat=false
